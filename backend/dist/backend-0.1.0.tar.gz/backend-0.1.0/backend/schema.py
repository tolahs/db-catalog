import strawberry

@strawberry.type
class CatalogType:
    id: int
    name: str
    description: str

@strawberry.input
class CatalogInput:
    name: str
    description: str
    