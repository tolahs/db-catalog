from backend.model.catalog import Catalog
from backend.config import db
from sqlalchemy import select, update as sql_update, delete as sql_delete


class CatalogRepository:

    @staticmethod
    async def asyn_create(catalog_data: Catalog):
        async with db as session:
            async with session.begin():
                session.add(catalog_data)
            await db.commit_rollback()

    @staticmethod
    async def get_by_id(catalog_id: int):
        async with db as session:
            stmt = select(Catalog).where(Catalog.id == catalog_id) # type: ignore
            result = await session.execute(stmt)
            catalog = result.scalars().first()
            return catalog

    @staticmethod
    async def get_all():
        async with db as session:
            query = select(Catalog)
            result = await session.execute(query)
            return result.scalars().all()

    @staticmethod
    async def update(id: int, catalog_data: Catalog):
        async with db as session:
            stmt = select(Catalog).where(Catalog.id == id) # type: ignore
            result = await session.execute(stmt)

            catalog = result.scalars().first()
            if catalog is None:
                raise ValueError(f"Catalog with id {id} not found")

            catalog.name = catalog_data.name
            catalog.description = catalog_data.description

            query = sql_update(Catalog).where(Catalog.id == id).values( # type: ignore
                **catalog_data.model_dump()).execution_options(synchronize_session="fetch")
            await session.execute(query)
            await db.commit_rollback()

    @staticmethod
    async def delete(id: int):
        async with db as session:
            query = sql_delete(Catalog).where(Catalog.id == id) # type: ignore
            await session.execute(query)
            await db.commit_rollback()
