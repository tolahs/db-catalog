from sqlmodel import Field, SQLModel
from typing import Optional
import random


class Catalog(SQLModel, table=True): # type: ignore
    __tablename__ = "catalog" # type: ignore
    id: Optional[int] = Field(None, primary_key=True, nullable=False)
    name: str = Field(index=True)
    description: str


