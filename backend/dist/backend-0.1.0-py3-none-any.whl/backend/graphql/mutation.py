
from backend.schema import CatalogInput, CatalogType
from backend.service.catalog import CatalogService

import strawberry 



@strawberry.type
class Mutation:
    
    @strawberry.mutation
    async def create_catalog(self, catalog_data: CatalogInput) -> CatalogType:
        return await CatalogService.add_catalog(catalog_data)
    
    @strawberry.mutation
    async def delete_catalog(self, catalog_id: int) -> str:
        return await CatalogService.delete(catalog_id)
    
    @strawberry.mutation
    async def update_catalog(self, catalog_id: int, catalog_data: CatalogInput) -> str:
        return await CatalogService.update(catalog_id, catalog_data)
    