import strawberry
from typing import List
from backend.service.catalog import CatalogService
from backend.schema import CatalogType

@strawberry.type
class Query:

    @strawberry.field
    def hello(self) -> str:
        return "Hello, World!"

    @strawberry.field
    async def get_all(self) -> List[CatalogType]:
        return await CatalogService.get_all_catalogs()
    
    @strawberry.field
    async def get_by_id(self, id: int) -> CatalogType:
        return await CatalogService.get_by_id(id)