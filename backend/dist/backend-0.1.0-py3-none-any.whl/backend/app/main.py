from fastapi import FastAPI
from backend.config import AsyncDatabaseSession
from contextlib import asynccontextmanager

from strawberry.fastapi import GraphQLRouter
import strawberry

from ..graphql.query import Query
from ..graphql.mutation import Mutation

def init_app() -> FastAPI:
    db = AsyncDatabaseSession()
    
    @asynccontextmanager
    async def lifespan(app: FastAPI):
        await db.create_all()
        try:
            yield
        finally:
            await db.close()
    
    app = FastAPI(
        lifespan=lifespan,
        title="Db Catalog Backend Server",
        description="Db Catalog Backend Server",
        debug=True)
    
    @app.get("/")
    def read_root():
        return "Welocome to Db Catalog Backend Server"
    
    # add graphql endpoint
    schema = strawberry.Schema(query=Query, mutation=Mutation)
    graphql_app = GraphQLRouter(schema)
    app.include_router(graphql_app, prefix="/graphql")
    
    return app


app: FastAPI = init_app()


